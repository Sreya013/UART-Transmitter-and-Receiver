`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 06.05.2026 17:08:23
// Design Name: 
// Module Name: baud_rate_gen
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// baud_rate_gen.v
module baud_rate_gen (
    input  clk,        // 50MHz system clock
    input  rst,
    output reg baud_tick
);
    // 50MHz / 9600 = 5208 cycles per bit
    parameter BAUD_DIV = 5208;
    integer count;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            count     <= 0;
            baud_tick <= 0;
        end else if (count == BAUD_DIV - 1) begin
            count     <= 0;
            baud_tick <= 1;
        end else begin
            count     <= count + 1;
            baud_tick <= 0;
        end
    end
endmodule
