`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 06.05.2026 17:39:09
// Design Name: 
// Module Name: uart_rx
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

// uart_rx.v
module uart_rx (
    input        clk,
    input        rst,
    input        baud_tick,
    input        rx,
    output reg [7:0] rx_data,
    output reg       rx_done
);
    // FSM States
    parameter IDLE  = 2'b00;
    parameter START = 2'b01;
    parameter DATA  = 2'b10;
    parameter STOP  = 2'b11;

    reg [1:0] state;
    reg [2:0] bit_index;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state     <= IDLE;
            rx_data   <= 8'b0;
            rx_done   <= 0;
            bit_index <= 0;
        end else begin
            case (state)
                IDLE: begin
                    rx_done <= 0;
                    if (rx == 0)       // detect start bit (LOW)
                        state <= START;
                end

                START: begin
                    if (baud_tick) begin
                        if (rx == 0) begin  // confirm start bit
                            state     <= DATA;
                            bit_index <= 0;
                        end else
                            state <= IDLE;  // false start, go back
                    end
                end

                DATA: begin
                    if (baud_tick) begin
                        rx_data[bit_index] <= rx;
                        if (bit_index == 7)
                            state <= STOP;
                        else
                            bit_index <= bit_index + 1;
                    end
                end

                STOP: begin
                    if (baud_tick) begin
                        if (rx == 1) begin  // valid stop bit
                            rx_done <= 1;
                        end
                        state <= IDLE;
                    end
                end
            endcase
        end
    end
endmodule
